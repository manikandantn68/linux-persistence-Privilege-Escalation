
#include <stdio.h>
#include <string.h>

int main(void)
{
    char str[] = "9J<q=^\\':h*#*d:#+Jh*9)#\\'+#>)\\'Bs";

    int i = 0;

    // Allocate space for the string and null terminator
    char res[strlen(str) + 1];

    // Add 10 to each character
    while (str[i] != '\0')
    {
        res[i] = str[i] + 10;
        i++;
    }

    // Null terminator
    res[i] = '\0';

    printf("%s\n", res);

    return 0;
}
