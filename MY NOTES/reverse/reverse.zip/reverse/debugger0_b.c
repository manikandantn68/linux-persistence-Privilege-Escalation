#include <stdio.h>

int main(void)
{
    int result = 123098;
    int i = 0;

    while (i < 607)
    {
        result = result + i;
        i++;
    }

    printf("%d\n", result);

    return 0;
}
