#include <stdio.h>

int main()
{
    char str[] = "This is a red herring";
    int i = 0;
    int result = 102;

    while (str[i]) {
        result += str[i];
        i++;
    }

    printf("%d\n", result);

    return 0;
}
