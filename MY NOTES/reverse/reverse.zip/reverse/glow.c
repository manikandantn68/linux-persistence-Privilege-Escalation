
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
    char key[6];

    char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    int len = strlen(charset);

    srand(time(NULL));

    key[0] = charset[rand() % len];
    key[1] = '@';

    while (1)
    {
        key[2] = charset[rand() % len];
        key[3] = charset[rand() % len];

        key[4] = 300 - key[2] - key[3];

        if (key[4] >= 32 && key[4] <= 126)
        {
            break;
        }
    }

    key[5] = '\0';

    printf("Generated key: %s\n", key);

    return 0;
}
