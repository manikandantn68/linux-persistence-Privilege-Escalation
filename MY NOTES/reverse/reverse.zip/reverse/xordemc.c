
#include <stdio.h>

int main(void)
{
    char arr_1[10];
    char arr_2[10];
    char result[10];

    // First string
    arr_1[0] = 0x62;
    arr_1[1] = 0x61;
    arr_1[2] = 100;
    arr_1[3] = 0x62;
    arr_1[4] = 0x65;
    arr_1[5] = 0x65;
    arr_1[6] = 0x66;
    arr_1[7] = 0x31;
    arr_1[8] = 0x32;
    arr_1[9] = 0;

    // Second string
    arr_2[0] = 0x10;
    arr_2[1] = 0x14;
    arr_2[2] = 10;
    arr_2[3] = 5;
    arr_2[4] = 0x0c;
    arr_2[5] = 0x17;
    arr_2[6] = 10;
    arr_2[7] = 2;
    arr_2[8] = 6;
    arr_2[9] = 0;

    // XOR operation
    int i = 0;

    while (i < 9)
    {
        result[i] = arr_1[i] ^ arr_2[i];
        i++;
    }

    // Null terminator
    result[i] = '\0';

    printf("Result: %s\n", result);

    return 0;
}
