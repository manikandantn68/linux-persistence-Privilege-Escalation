#include <stdio.h>

void greet(void){

printf("hello  form a void function \n");
}

int main(){
char grade='a';
int age=20;
float price=22.29f;
double pi= 2.23232323;
bool istrue=true;
char word[] = "welcome";

printf("character : %c \n",grade);
printf("integer   : %d \n",age);
printf("float     : %f \n",price);
printf("double    : %10f \n",pi);
printf("boolean   : %d \n",istrue);
printf("words     : %s \n",word);
greet();

return 0;
}
