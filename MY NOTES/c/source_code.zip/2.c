#include <stdio.h>

int main(void){


char name[100];
printf("enter your name: ");

if(fgets(name,sizeof(name), stdin) != NULL)
{
printf("hello , %s",name);
}
return 0;
}
