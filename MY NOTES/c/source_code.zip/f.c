#include <stdio.h>

int main(){

const  int age = 20;
printf("our age is %d",age);

return 0;
}
