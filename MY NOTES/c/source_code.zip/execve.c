#include <stdio.h>
#include <unistd.h>

extern char **environ;

int main(void)
{
    char *args[] = {"ls", "-l", NULL};

    execve("/bin/ls", args, environ);

    perror("execve failed");
    return 1;
}
