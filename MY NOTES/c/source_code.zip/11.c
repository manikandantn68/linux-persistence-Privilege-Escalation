#include <stdio.h>
#include <stdlib.h>
int main(void){



for(int i =1; i <= 5; i++){
printf("%d\n",i);

for(int j =1; j <= 4; j++){
printf("%d\n",j);

}

printf("\n");
}
return 0;
}
