#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void){

char message[]= "hello manikandan\n";
write(1,message ,sizeof(message) - 1);

return 0;
}


