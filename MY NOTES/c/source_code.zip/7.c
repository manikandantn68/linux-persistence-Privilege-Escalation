#include <stdio.h>
#include <stdlib.h>
int main(void){


int  choice =4;

switch(choice){
case 1:
printf(" your are good person \n");
break;
case 2:
printf(" your are nice person  \n");
break;
case 3:
printf(" your are good man \n");
break;
case 4:
printf(" your are good women \n");
break;
case 5:
printf(" have a nice day  \n");
break;

default:
printf(" dont feel your life is already happy \n");
break;

}

return 0;
}


