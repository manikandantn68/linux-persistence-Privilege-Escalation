
#include <stdio.h>

#define MAX 5

int stack[MAX];
int top = -1;

// Insert an element into the stack
void push(int value)
{
    if (top == MAX - 1)
    {
        printf("Stack Overflow! Stack is full.\n");
        return;
    }

    stack[++top] = value;
    printf("%d pushed into stack.\n", value);
}

// Remove the top element
void pop(void)
{
    if (top == -1)
    {
        printf("Stack Underflow! Stack is empty.\n");
        return;
    }

    printf("%d popped from stack.\n", stack[top--]);
}

// View the top element
void peek(void)
{
    if (top == -1)
    {
        printf("Stack is empty.\n");
        return;
    }

    printf("Top element: %d\n", stack[top]);
}

// Display all elements from top to bottom
void display(void)
{
    if (top == -1)
    {
        printf("Stack is empty.\n");
        return;
    }

    printf("Stack (top to bottom):\n");

    for (int i = top; i >= 0; i--)
    {
        printf("| %d |\n", stack[i]);
    }
}

int main(void)
{
    int choice, value;

    while (1)
    {
        printf("\n--- STACK MENU ---\n");
        printf("1. PUSH\n");
        printf("2. POP\n");
        printf("3. PEEK\n");
        printf("4. DISPLAY\n");
        printf("5. EXIT\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1)
        {
            printf("Invalid input.\n");
            return 1;
        }

        switch (choice)
        {
            case 1:
                printf("Enter value: ");

                if (scanf("%d", &value) != 1)
                {
                    printf("Invalid input.\n");
                    return 1;
                }

                push(value);
                break;

            case 2:
                pop();
                break;

            case 3:
                peek();
                break;

            case 4:
                display();
                break;

            case 5:
                printf("Program terminated.\n");
                return 0;

            default:
                printf("Invalid choice. Try again.\n");
        }
    }
}
