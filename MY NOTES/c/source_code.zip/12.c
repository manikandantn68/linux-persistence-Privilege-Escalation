#include <stdio.h>
#include <stdlib.h>
int main(void){

int number = 10;
int *ptr = &number;
printf("value :%d\n",number);
printf("address:  %p\n",ptr);
printf("pointer value :%d\n",*ptr);


return 0;
}


