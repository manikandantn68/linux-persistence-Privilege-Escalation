#include <stdio.h>

int person_fav = 530; //global variable

int main(){
 int age;
 age = 1;
 
 int Age;
 Age = 2;  //local variable
 
 int price =200;
printf("hello %d %d %d %d\n",age,Age,price,person_fav);

return 0;

}
