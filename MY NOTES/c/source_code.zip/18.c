
#include <stdio.h>
#include <stdlib.h>
int main(void){

FILE *fp;

fp =fopen("data.txt","a");
if(fp == NULL){
printf("error opening file!\n");

return 1;
}

fprintf(fp,"this line was apppended \n");

fclose(fp);

printf(" success\n");
return 0;
}


