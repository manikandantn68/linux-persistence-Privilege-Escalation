

#include <stdio.h>
#include <stdlib.h>
int main(void){

FILE *fp;

fp =fopen("data.txt","w");
if(fp == NULL){
printf("error opening file!\n");

return 1;
}

fprintf(fp,"hellow form c!\n");
fprintf(fp,"this write mode!\n");

fclose(fp);

printf(" data written success\n");
return 0;
}


