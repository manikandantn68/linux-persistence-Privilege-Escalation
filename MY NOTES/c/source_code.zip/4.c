#include <stdio.h>
#include <stdlib.h>
int main(void){

int age =50;
if(age >= 18){
printf("your are an adult. \n");
}else{
printf("your are not an  adult. \n");
}

return 0;
}


