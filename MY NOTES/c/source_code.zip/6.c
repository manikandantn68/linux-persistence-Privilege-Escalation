#include <stdio.h>
#include <stdlib.h>
int main(void){

int age = 10;
int has_id= 1;

if(age >= 18){
printf("age condition is true  \n");

if(has_id == 1){
printf("id condition is true\n");
printf("entry allowd \n");

}
}

return 0;
}


