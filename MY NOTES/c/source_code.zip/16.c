#include <stdio.h>
#include <stdlib.h>
void change(int *x){

*x= 100;
printf("inside function :  %d\n",x);

}

int main(void){

int number = 10;
printf("before function call:  %d\n", number);

change(&number);
printf("after function call:  %d\n", number);

return 0;
}





