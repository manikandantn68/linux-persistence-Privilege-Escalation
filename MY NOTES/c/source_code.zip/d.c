#include <stdio.h>

int main(void){

int x;
int a = 10;
int b = 3;

printf("a = %d\n",a);
printf("b = %d\n",b);

//add

printf("add : %d\n",a + b);

//sub
printf("sub : %d\n",a - b);

//mul
printf("mul : %d\n",a * b);

//div
printf("div : %d\n",a / b);

//modulus
printf("mod : %d\n",a % b);

//increment
a++;
printf("in : %d\n",a );

//de
b--;
printf("de : %d\n",b);

return 0;
}
