#include <stdio.h>

int main(void){

char  mark[5] ={'a','b','c','d','e'};
printf("1 mark: %c\n",mark[0]);
printf("2 mark: %c\n",mark[1]);
printf("3 mark: %c\n",mark[2]);
printf("4 mark: %c\n",mark[3]);
printf("5 mark: %c\n",mark[4]);

return 0;
}


