#include <stdio.h>
#include <stdlib.h>
int main(void){

int marks;

printf("enter your marks (0-100): ");

if(scanf("%d",&marks) != 1){

printf("invalid marks\n");

return 1;
}


if(marks < 0 || marks > 100){

printf("invalid marks\n");
}else if(marks >= 90){
printf("grade 1\n");
}else if(marks >= 80){
printf("grade 2\n");
}else if(marks >= 70){
printf("grade 3\n");
}else if(marks >= 60){
printf("grade 4\n");
}else if(marks >= 50){
printf("grade 5\n");
}else if(marks >= 40){
printf("grade 6\n");
}else if(marks >= 30){
printf("grade 7\n");
}else if(marks >= 20){
printf("grade 8\n");
}else if(marks >= 10){
printf("grade 9\n");
}else if(marks >= 5){
printf("grade 10\n");
}else{
printf("fail \n");
}
return 0;
}


