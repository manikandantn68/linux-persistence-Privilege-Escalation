#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void){

pid_t pid = fork();

if(pid < 0){
perror("fork");
return 1;
}else if(pid == 0){
printf("i am the child process!\n");
printf("child process: id (pid) %d\n",(int)getpid());
}else{

printf("i am parent process\n ");
printf("parent process: id (ppid) %d\n",(int)getpid());

wait(NULL);
}

sleep(2000);
return 0;
}


