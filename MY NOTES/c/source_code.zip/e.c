#include <stdio.h>

int main(void){


int a = 10;
int b = 3;

printf("a = %d\n",a);
printf("b = %d\n",b);

printf("equal to(a == b): %d\n",a==b);
printf("not equal to(a != b): %d\n",a!=b);
printf("greater than(a > b): %d\n",a>b);
printf("less than(a < b): %d\n",a<b);
printf("greater  than equal (a >= b): %d\n",a>=b);
printf("less than equal(a <= b): %d\n",a<=b);

return 0;
}
   
