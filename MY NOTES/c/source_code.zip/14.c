#include <stdio.h>
#include <stdlib.h>
int add(int a,int b){
return a+b;
}

int main(void){

int (*func_ptr)(int,int) =add;
printf(" function result : %d\n",func_ptr(10,5));
return 0;
}



