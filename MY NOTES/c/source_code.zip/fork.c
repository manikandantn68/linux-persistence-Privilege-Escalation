#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void){

pid_t pid = fork();

if(pid == 0){

printf("i am the child process!\n");
}else if(pid > 0){
printf("i am the parent process!\n");
printf("child pid: %d\n",(int)pid);
}else{
perror("fork");
return 1;
}

sleep(2000);
return 0;
}


