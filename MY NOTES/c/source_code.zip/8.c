#include <stdio.h>
#include <stdlib.h>
int main(void){

int i=1;

do{
printf("%d\n",i);
i++;
}while(i <= 15);

return 0;
}

