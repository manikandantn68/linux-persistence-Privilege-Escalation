#include <stdio.h>
#include <stdlib.h>
int main(void){

int number = 10;
int *ptr = &number;

printf("before:  %d\n", number);

*ptr =50;
printf("after:  %d\n", number);

return 0;
}


