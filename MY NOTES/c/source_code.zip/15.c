#include <stdio.h>
#include <stdlib.h>
int main(void){

int number[3] = {10,1,3};

int (*ptr)[3] = &number;

printf("element 1:  %d\n",  (*ptr)[0]);
printf("element 2:  %d\n",  (*ptr)[1]);
printf("element 3:  %d\n",  (*ptr)[2]);

return 0;
}


