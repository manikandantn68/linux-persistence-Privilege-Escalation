#include <stdio.h>

int main(){

  int age;
 float price;
 double pi;
 char grade;
  
printf("enter your age: ");
scanf("%d",&age);

printf("enter your price: ");
scanf("%f",&price);

printf("enter your value: ");
scanf("%lf",&pi);

printf("enter your grade: ");
scanf("%c",&grade);

printf("\n --------user details----------\n");
printf(" age: %d\n",age);
printf(" price: %.2f\n",price);
printf(" pi: %.5f\n",pi);
printf(" grade: %c\n",grade);


return 0;

}
    
