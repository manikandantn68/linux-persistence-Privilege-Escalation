#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
#include <errno.h>

struct note {
    char text[16];
    void (*action)(void);
};

void normal(void)
{
    puts("Normal action.");
}

void win(void)
{
    puts("LAB_SUCCESS: Function pointer hijacked!");
}

int read_exact(int fd, void *buffer, size_t length)
{
    size_t total = 0;
    char *p = buffer;

    while (total < length) {
        ssize_t n = read(fd, p + total, length - total);

        if (n < 0 && errno == EINTR)
            continue;

        if (n <= 0)
            return -1;

        total += (size_t)n;
    }

    return 0;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    // Step 1: First allocation
    struct note *old = malloc(sizeof *old);

    if (old == NULL)
        return 1;

    old->action = normal;
    snprintf(old->text, sizeof old->text, "old note");

    uintptr_t old_address = (uintptr_t)old;

    // Save a pointer into the allocation
    char *stale_text = old->text;

    printf("Old allocation: %p\n", (void *)old);

    // Step 2: Free the allocation
    free(old);

    // Step 3: Allocate the same size again
    struct note *replacement = malloc(sizeof *replacement);

    if (replacement == NULL)
        return 1;

    replacement->action = normal;
    snprintf(replacement->text,
             sizeof replacement->text, "new note");

    printf("Replacement:   %p\n", (void *)replacement);

    printf("Function pointer offset: %zu\n",
           offsetof(struct note, action));

    if (old_address != (uintptr_t)replacement) {
        puts("LAYOUT_MISS: No allocation reuse.");
        free(replacement);
        return 0;
    }

    // Step 4: Intentional use-after-free write
    puts("Send a 24-byte payload.");
    puts("16 bytes text + 8 bytes function pointer.");

    if (read_exact(STDIN_FILENO, stale_text,
                   sizeof *replacement) != 0) {
        puts("Input error.");
        free(replacement);
        return 1;
    }

    // Step 5: Observe modified allocation
    printf("Replacement text: %.16s\n", replacement->text);

    // Step 6: Indirect function call
    puts("Calling replacement->action()...");

    replacement->action();

    free(replacement);

    return 0;
}
