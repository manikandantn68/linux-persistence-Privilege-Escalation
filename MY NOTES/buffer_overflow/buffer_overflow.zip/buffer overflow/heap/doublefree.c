
#include <stdio.h>      // Provides printf() and puts()
#include <stdlib.h>     // Provides malloc() and free()

int main(void)          // Program execution starts here
{
    setvbuf(stdout, NULL, _IONBF, 0);  // Disable stdout buffering

    void *ptr = malloc(0x40);          // Allocate 64 bytes on the heap

    if (ptr == NULL)                   // Check whether allocation failed
        return 1;                      // Exit if malloc returned NULL

    printf("Allocated address: %p\n", ptr); // Print allocated heap address

    free(ptr);                         // FIRST FREE: Release the allocation
    puts("[+] First free completed");  // Print confirmation

    free(ptr);                         // SECOND FREE: Same pointer freed again
                                       // BUG: This is a DOUBLE FREE
    puts("[+] Second free completed"); // Normally not executed with glibc

    return 0;                          // End program
}
