
#include <stdio.h>

int main(void)
{
    char input[256];

    printf("Enter your message: ");

    if (fgets(input, sizeof(input), stdin) == NULL)
    {
        return 1;
    }

    // VULNERABLE: user input is treated as a format string
    printf(input);

    return 0;
}
