#include <stdio.h>

int main(void)
{
    char secret[] = "manikandan";
    char input[10];

    printf("Enter your input: ");

    if (fgets(input, sizeof(input), stdin) == NULL)
        return 1;

    /* Intentionally vulnerable CTF demonstration */
    printf(input, secret);

    putchar('\n');
    return 0;
}
