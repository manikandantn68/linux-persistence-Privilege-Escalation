#include <stdio.h>
#include <unistd.h>

struct Data
{
    char name[16];
    int score;
};

int main()
{
    struct Data d = {0};

    printf("Enter name: ");
    read(0, d.name, 32);

    printf("Score = %d\n", d.score);

    if (d.score == 1337)
        printf("Special score reached!\n");
    else
        printf("Normal score\n");

    return 0;
}
