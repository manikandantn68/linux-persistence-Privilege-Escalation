#include <stdio.h>
#include <unistd.h>

void normal(void)
{
    printf("Normal function\n");
}

void special(void)
{
    printf("Special function reached!\n");
}

struct Frame
{
    char buffer[16];
    void (*func)(void);
};

int main(void)
{
    struct Frame f = {0};

    f.func = normal;

    printf("Enter input: ");
    read(0, f.buffer, 32);

    f.func();

    return 0;
}
