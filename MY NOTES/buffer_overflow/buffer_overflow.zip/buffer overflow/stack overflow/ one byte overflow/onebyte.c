#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <stddef.h>

typedef void (*handler_t)(void);

void normal_handler()
{
    puts("Normal handler executed.");
}

void target_handler()
{
    puts("TARGET HANDLER EXECUTED!");
}

struct Frame
{
    char buffer[8];
    handler_t handler;
};

int main()
{
    struct Frame *f = malloc(sizeof(struct Frame));

    f->handler = normal_handler;

    printf("normal_handler = %p\n", (void *)normal_handler);
    printf("target_handler = %p\n", (void *)target_handler);

    printf("buffer offset  = %zu\n",
           offsetof(struct Frame, buffer));

    printf("handler offset = %zu\n",
           offsetof(struct Frame, handler));

    printf("Enter 9 bytes: ");

    /*
     * BUG:
     * buffer is only 8 bytes,
     * but read() accepts 9 bytes.
     */
    read(0, f->buffer, 9);

    f->handler();

    free(f);
    return 0;
}
