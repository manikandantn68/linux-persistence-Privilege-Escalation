#include <stdio.h>
#include <unistd.h>

void collect_note(void)
{
    char note[24];

    printf("Enter note: ");
    read(0, note, 40);       // BUG: 40 bytes into a 24-byte buffer

    puts("Note received.");
}

int main(void)
{
    unsigned long marker = 0x1122334455667788;

    collect_note();

    printf("marker = 0x%lx\n", marker);

    return 0;
}
