import struct

payload = b"A" * 32
payload += struct.pack("<Q", 0x4141414141414141)

with open("payload.bin", "wb") as f:
    f.write(payload)

print("payload length:", len(payload))
