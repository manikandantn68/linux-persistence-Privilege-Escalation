// vuln2.c
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

void win() {
    system("/bin/sh");
}

int vuln() {
    char note[64];
    int size;

    memset(note, 'A', sizeof(note));
    write(1, note, sizeof(note) + 16);   // was +8, now +16 — reaches past padding into canary

    printf("size: ");
    scanf("%d", &size);
    getchar();

    printf("note: ");
    read(0, note, size);

    return 0;
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    vuln();
    return 0;
}
