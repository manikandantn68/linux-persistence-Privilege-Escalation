#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void win()
{
    puts("YOU REACHED WIN!");
    exit(0);
}

void vuln()
{
    char buffer[32];

    puts("Enter input:");
    read(0, buffer, 200);   // BUG: can write far beyond buffer
    puts("Done");
}

int main()
{
    vuln();
    return 0;
}
