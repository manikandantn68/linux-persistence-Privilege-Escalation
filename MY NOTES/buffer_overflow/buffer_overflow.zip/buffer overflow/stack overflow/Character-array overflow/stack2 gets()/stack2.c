#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void access_granted()
{
    puts("ACCESS GRANTED!");
    exit(0);
}

void login()
{
    char username[24];

    printf("Enter username: \n");
    read(0, username, 200);   // intentional overflow
    printf("Hello\n");
}

int main()
{
    login();
    return 0;
}
