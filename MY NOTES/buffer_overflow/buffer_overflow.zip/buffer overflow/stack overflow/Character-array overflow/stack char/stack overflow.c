#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void win()
{
    printf("YOU REACHED WIN!\n");
    exit(0);
}

void vuln()
{
    char buffer[16];

    printf("Enter input: ");
    read(0, buffer, 100);

    printf("Done\n");
}

int main()
{
    vuln();
    return 0;
}
