#include <stdio.h>

void vuln()
{
    char buffer[16];
    int access = 0;

    printf("Input: ");
    scanf("%s", buffer);

    printf("access = %d\n", access);
}

int main()
{
    vuln();
    return 0;
}
