#include <stdio.h>
#include <unistd.h>

struct Frame
{
    char buffer[16];
    int is_admin;
};

int main()
{
    struct Frame f = {0};

    printf("Enter name: ");
    read(0, f.buffer, 32);

    if (f.is_admin == 1)
        printf("ADMIN ACCESS!\n");
    else
        printf("Normal user\n");

    return 0;
}
